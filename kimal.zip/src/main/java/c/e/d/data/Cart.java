package c.e.d.data;

import java.util.List;

public class Cart {
	Item item;
	List<Option> option;
	
	Cart(){}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public List<Option> getOption() {
		return option;
	}

	public void setOption(List<Option> option) {
		this.option = option;
	}

	



	


	
	
}
