package c.e.d;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KimalApplication {

	public static void main(String[] args) {
		SpringApplication.run(KimalApplication.class, args);
	}

}
