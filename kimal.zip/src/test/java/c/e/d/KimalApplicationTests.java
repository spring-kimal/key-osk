package c.e.d;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KimalApplicationTests {

	@Test
	void contextLoads() {
	}

}
