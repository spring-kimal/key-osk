package c.e.d.data;

public class Option_class {
	int opclId;
	String opclName;
	
	
	public int getOpclId() {
		return opclId;
	}


	public void setOpclId(int opclId) {
		this.opclId = opclId;
	}


	public String getOpclName() {
		return opclName;
	}


	public void setOpclName(String opclName) {
		this.opclName = opclName;
	}


	public Option_class() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Option_class(int opclId, String opclName) {
		super();
		this.opclId = opclId;
		this.opclName = opclName;
	}
	
}
