package c.e.d.controller;

import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import c.e.d.data.Item;
import c.e.d.data.ItemOrder;
import c.e.d.data.Option_class;
import c.e.d.data.Order;
import c.e.d.data.Payment;
import c.e.d.mapper.CatMapper;
import c.e.d.mapper.IngMapper;
import c.e.d.mapper.ItemMapper;
import c.e.d.mapper.Item_orderMapper;
import c.e.d.mapper.Option_classMapper;
import c.e.d.mapper.OrderMapper;
import c.e.d.mapper.OrderOptionMapper;
import c.e.d.mapper.PaymentMapper;

@Controller
public class WebController {

	@Value("PROJECT_LOC")
	String filepath;

	@Autowired
	public ItemMapper itemMapper;
	@Autowired
	public OrderOptionMapper orderOptionMapper;
	@Autowired
	public Option_classMapper option_classMapper;
	@Autowired
	public CatMapper catMapper;
	@Autowired
	public IngMapper ingMapper;
	@Autowired
	public PaymentMapper paymentMapper;
	@Autowired
	public OrderMapper orderMapper;
	@Autowired
	Item_orderMapper item_orderMapper;

	@GetMapping("/")
	public String main3() {
		Path path = FileSystems.getDefault().getPath("");
		String directoryName = path.toAbsolutePath().toString();
		System.out.println("Current Working Directory is = " + directoryName);
		return "main";
	}

	@GetMapping("/adduser")
	public String adduser() {
		return "adduser";
	}

	@GetMapping("/searchAll")
	public String searchAll(Model model) {
		model.addAttribute("items", itemMapper.findAlldesc());
		return "searchAll";
	}

	@GetMapping("/searchAll/{itemId}")
	public String searchAll(Model model, @PathVariable("itemId") int itemId) {
		model.addAttribute("cats", catMapper.findAll());

		model.addAttribute("item", itemMapper.findById(itemId).get());
		return "update";
	}

	@GetMapping("/itemAdd")
	public String itemAdd(Model model) {
		model.addAttribute("cats", catMapper.findAll());
		model.addAttribute("ings", ingMapper.findAll());
		return "itemAdd";
	}

	@GetMapping("/optAdd")
	public String optAdd(Model model) {
		List<Option_class> search = option_classMapper.findAll();
		model.addAttribute("opcls", search);

		return "optAdd";
	}

	@GetMapping("/catAdd")
	public String catAdd() {
		return "catAdd";
	}

	@GetMapping("/ingAdd")
	public String ingAdd() {
		return "ingAdd";
	}

	@GetMapping("pay")
	   public String pay(Model model) {
	      List<Payment> pays = paymentMapper.findAll();
	      model.addAttribute("pays", pays);
	      return "pay";
	   }

	@GetMapping("maechool")
	public String maechool(Model model) {
		List<ItemOrder> itemOrders = item_orderMapper.findAll();
		List<Item> items = itemMapper.findAll();
		List<Payment> pays = paymentMapper.findAll();
		List<Order> orders = orderMapper.findAll();
		
		int[] itemObj = new int[items.size()];
		List<Chartdata> a = new ArrayList<>();
		for (int i = 0; i < pays.size(); i++) {
			
			if (i != 0) {
				if (pays.get(i).getPayTime().getMonth() != pays.get(i-1).getPayTime().getMonth()) {
					a.add(new Chartdata(pays.get(i-1).getPayTime().getMonth(),itemObj));
					itemObj = new int[items.size()];
				}
			}
			for (int j = 0; j < itemOrders.size(); j++) {
				 {
					for(int k=0;k<items.size();k++) {
						if (pays.get(i).getOrdNumber() == itemOrders.get(j).getOrdNumber()) {
							itemObj[k] = itemObj[k] + itemOrders.get(j).getItemQuantity();
						}
						else break;
					}
				} 
			}
		}
		
		model.addAttribute("itemOrders", itemOrders );
		model.addAttribute("items", items);
		model.addAttribute("pays", pays);
		model.addAttribute("orders", orders);

		return "maechool";
	}

	@GetMapping("/denied")
	public String denied() {
		return "denied";
	}

	@GetMapping("/itemView")
	public String itemView(Model model) {
		model.addAttribute("items", itemMapper.findVisibleDesc());
		return "itemView";
	}
	
	class Chartdata{
		int date;
		int[] items;
		public Chartdata(int i, int[] items) {
			super();
			this.date = i;
			this.items = items;
		}
		public Chartdata() {
			super();
			// TODO Auto-generated constructor stub
		}
		public int getDate() {
			return date;
		}
		public void setDate(int date) {
			this.date = date;
		}
		public int[] getItems() {
			return items;
		}
		public void setItems(int[] items) {
			this.items = items;
		}
	}
}
