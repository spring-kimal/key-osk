package c.e.d.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import c.e.d.data.Payment;
@Mapper
public interface PaymentMapper {

	
	@Insert("Insert into payment(payId, payPrice, payTime, ordNumber) values (Null, #{priceTotal},Null, #{ordNumber}) ")
	void savePayment(@Param("priceTotal")int priceTotal, @Param("ordNumber")int ordNumber);
	@Select("select * from payment order by payTime")
	public List<Payment> findAll();
}
