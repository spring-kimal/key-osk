package c.e.d.data;

import java.sql.Timestamp;

public class Payment {
	int payId;
	int payPrice;
	Timestamp payTime;
	int ordNumber;
	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Payment(int payId, int payPrice, Timestamp payTime, int ordNumber) {
		super();
		this.payId = payId;
		this.payPrice = payPrice;
		this.payTime = payTime;
		this.ordNumber = ordNumber;
	}
	public int getPayId() {
		return payId;
	}
	public void setPayId(int payId) {
		this.payId = payId;
	}
	public int getPayPrice() {
		return payPrice;
	}
	public void setPayPrice(int payPrice) {
		this.payPrice = payPrice;
	}
	public Timestamp getPayTime() {
		return payTime;
	}
	public void setPayTime(Timestamp payTime) {
		this.payTime = payTime;
	}
	public int getOrdNumber() {
		return ordNumber;
	}
	public void setOrdNumber(int ordNumber) {
		this.ordNumber = ordNumber;
	}
	
	
}
