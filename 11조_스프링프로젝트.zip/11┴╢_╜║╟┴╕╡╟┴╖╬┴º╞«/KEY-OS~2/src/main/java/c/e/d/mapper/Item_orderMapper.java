package c.e.d.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import c.e.d.data.ItemOrder;

@Mapper
public interface Item_orderMapper {
	@Select("select * from item_order")
	public List<ItemOrder> findAll();
}
